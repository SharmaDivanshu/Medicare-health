package com.cognizant.Dao;

import com.cognizant.entity.Admin;
import com.cognizant.entity.Login;

public interface LoginDAO {

	int checkLogin(Login login);

}
